package conectak;

import java.util.List;

import espaciojuego.Juego;
import jugadores.Jugador;
import jugadores.JugadorAleatorio;
import jugadores.JugadorAlfaBeta;
import jugadores.JugadorEvaluar;
import jugadores.JugadorEvaluarTV;

public class TestConectaK {

	public static void main(String[] args) {
		
		
		//aleatorio();
		//aleatorioHumano();
		//evaluarHumano();
		//evaluarTVHumano();
		evaluarTVAlfaBeta();
	}
	
    
    public static void aleatorio(){
        ConectaK e = new ConectaK(3,3,3);
        Jugador j1 = new JugadorAleatorio<ConectaK>();
        Jugador j2 = new JugadorAleatorio<ConectaK>();
        Juego juego1 = new Juego(j1, j2, e);
        
        verPartida(juego1);
    }
    
    public static void aleatorioHumano(){
        ConectaK e = new ConectaK(3,3,3);
        Jugador j1 = new JugadorAleatorio<ConectaK>();
        Jugador j2 = new JugadorHumanoCK();
        Juego juego1 = new Juego(j1, j2, e);
        
        verPartida(juego1);       
    }
    
    
    public static void evaluarHumano(){
        ConectaK e = new ConectaK(3,3,3);
        Jugador j1 = new JugadorEvaluar(new EvaluadorCK(3,3,3));
        Jugador j2 = new JugadorHumanoCK();
        Juego juego1 = new Juego(j1, j2, e);
        
        verPartida(juego1);       
    }
    
    public static void evaluarTVHumano(){
        ConectaK e = new ConectaK(3,3,3);
        JugadorEvaluarTV<ConectaK> j1 = new JugadorEvaluarTV();
        
        
        //entrenamos
        double epsilon = 0.1;//probabilidad de exploración
        int nPartidas = 5000;
        Jugador ja = new JugadorAleatorio();
        System.out.println("Entrenando...");
        for(int i = 0; i< nPartidas; i++){
        	j1.aprendeTurno1(ja, e, epsilon);
        }
        System.out.println("OK");
        
        //jugamos
        Jugador j2 = new JugadorHumanoCK();
        Juego juego1 = new Juego(j1, j2, e);
        
        verPartida(juego1);
    }
    
    public static void evaluarTVAlfaBeta(){
        ConectaK e = new ConectaK(3,3,3);
        JugadorEvaluarTV<ConectaK> j2 = new JugadorEvaluarTV();
        Jugador j1 = new JugadorAlfaBeta<>(new EvaluadorCK(3,3,3), 4);
        
        //entrenamos
        double epsilon = 0.1;//probabilidad de exploración
        int nPartidas = 5000;
        Jugador ja = new JugadorAlfaBeta<>(new EvaluadorCK(3,3,3), 1);
        System.out.println("Entrenando...");
        for(int i = 0; i< nPartidas; i++){
        	j2.aprendeTurno1(ja, e, epsilon);
        }
        System.out.println("OK");
        
        //jugamos
        Juego juego1 = new Juego(j1, j2, e);
        
        verPartida(juego1);
    }
    
      
public static void verPartida (Juego juego){
        int i =  juego.jugarPartida(true);
        
        if (i == 0){
            System.out.println("Empate.");
        } else if (i == 1) {
            System.out.println("Gana el primer jugador.");
        } else {
            System.out.println("Gana el segundo jugador.");
        }
    }

	
	
	

}
